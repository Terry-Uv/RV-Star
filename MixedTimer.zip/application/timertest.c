#include "multi_timer.h"
#include <stdio.h>
#include "nuclei_sdk_soc.h"
/* Define the interrupt handler name same as vector table in case download mode is flashxip. */
#define mtimer_irq_handler     eclic_mtip_handler
#define mtimer_sw_irq_handler  eclic_msip_handler

struct Timer timer1;
struct Timer timer2;
struct Timer timer3;

static uint32_t count=0;
//读取reg,毫秒级精度提供时基
void wait_mseconds(size_t n)
{
    uint64_t start_mtime, delta_mtime;

    uint64_t tmp = SysTimer_GetLoadValue();
    do {
        start_mtime = SysTimer_GetLoadValue();
    } while (start_mtime == tmp);

    do {
        delta_mtime = SysTimer_GetLoadValue() - tmp;
    } while (delta_mtime < ( n * SOC_TIMER_FREQ));
}

void setup_timer()
{
    printf("init timer and start\n\r");
    uint64_t now = SysTimer_GetLoadValue();
    uint64_t then = now + 0.5 * SOC_TIMER_FREQ;
    SysTimer_SetCompareValue(then);
}

//硬件timer绑定
void mtimer_irq_handler(void)
{
    wait_mseconds(1);
//     printf("MTimer IRQ handler %d\n\r",count);
     count++;
    timer_ticks();          //最为关键的绑定时基
    uint64_t now = SysTimer_GetLoadValue();
    SysTimer_SetCompareValue(now + 0.5 * SOC_TIMER_FREQ);
}

//Timer回调函数
void timer1_callback()
{
    printf("timer1 timeout!\r\n");
}

void timer2_callback()
{
    printf("timer2 timeout!\r\n");
}

void timer3_callback()
{
    printf("timer3 timeout!\r\n");
}



int main(void)
{
    uint32_t returnCode;

    //绑定
    returnCode = ECLIC_Register_IRQ(
        SysTimer_IRQn, ECLIC_NON_VECTOR_INTERRUPT, ECLIC_LEVEL_TRIGGER, 1, 0,
        mtimer_irq_handler); /* register system timer interrupt */

    __enable_irq(); /* enable global interrupt */

    setup_timer(); /* initialize timer */


    timer_initial(&timer1, timer1_callback, 1, 1);   //1s超时，然后每1s输出，周期输出点为：1，2，3，4，5，6
	timer_start(&timer1);

	timer_initial(&timer2, timer2_callback, 2, 2);   //2s超时，然后每2s输出，周期输出点为：2，4，6
	timer_start(&timer2);

	timer_initial(&timer3, timer3_callback, 3,3); 	//3s超时，然后每3s输出，周期输出点为：3,6
	timer_start(&timer3);

    while (1)
      {
    		timer_loop();
      }
    
}
