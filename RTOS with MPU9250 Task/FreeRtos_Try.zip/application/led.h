void led_all(void);
void gpio_config();

/**
    \brief      configure the TIMER peripheral
    \param[in]  none
    \param[out] none
    \retval     none
*/
void timer_config();

/**
    \brief      configure the rgb_led
    \param[in]  temp1:set value of red channel between 0 to 255
    \param[in]  temp2:set value of green channel between 0 to 255
    \param[in]  temp3:set value of blue channel between 0 to 255
    \param[out] none
    \retval     none
*/
void rgb_config(int temp1,int temp2,int temp3);
